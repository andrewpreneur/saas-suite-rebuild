# Capability map — verified against the live LeadConnector MCP catalog

Probed directly via `search_operations`. Treat this as the ground truth for what to promise. Where it says ❌, the operation is genuinely absent from the catalog — no amount of rephrasing will find it.

## Contents
- [Quick verdict table](#quick-verdict-table)
- [Domain detail](#domain-detail)
- [Gotchas that cause failures](#gotchas-that-cause-failures)
- [Key request shapes](#key-request-shapes)
- [Discovery recipe](#discovery-recipe)

---

## Quick verdict table

| Domain | Read | Create/Update | Delete | Notes |
|---|---|---|---|---|
| Contacts | ✅ | ✅ | ✅ | Full CRUD + upsert, tags, notes, tasks, followers, business assignment, duplicate lookup |
| Opportunities | ✅ | ✅ | ✅ | Full CRUD + upsert, stage moves, status, followers |
| **Pipelines** | ✅ | ❌ | ❌ | **`get-pipelines` only.** Must be built in UI |
| Conversations / messages | ✅ | ✅ | ✅ | Send SMS/Email/WhatsApp/IG/FB/Custom/InternalComment, **scheduled sends**, cancel scheduled, transcriptions, recordings, export |
| Calendars / appointments | ✅ | ✅ | ✅ | Appointments, free slots, blocked slots, notes, service bookings, resources, schedules |
| Custom fields | ✅ | ✅ | ✅ | Plus folders. Two paths exist (see gotchas) |
| Custom values | ✅ | ✅ | ✅ | The account-wide config store — high leverage |
| Custom objects | ✅ | ✅ | — | Schema read/update, records |
| Email templates | ✅ | ✅ | — | Create, update, import from URL |
| Email campaigns | ✅ | ✅ | — | Create, update drafts, list, stats |
| **Workflows** | ✅ | ❌ | ❌ | **`get-workflow` + add/remove contact only.** No builder |
| Social planner | ✅ | ✅ | ✅ | Posts, categories, tags, queues, CSV import, calendar view |
| Invoices / estimates | ✅ | ✅ | ✅ | Create, send, void, record payment, schedules, templates, estimate→invoice |
| Payments | ✅ | ✅ | — | Orders, fulfillment, subscriptions, transactions, coupons |
| Products / store | ✅ | ✅ | ✅ | Products, prices, collections, inventory, reviews, shipping |
| Blogs | ✅ | ✅ | — | Sites, authors, categories, posts, slug checks |
| **Forms / surveys** | ✅ submissions | ❌ | ❌ | **Read submissions only.** No builder |
| Tags (location) | ✅ | — | — | `get-location-tags`. Tags are created implicitly by applying them to a contact |
| Users | ✅ | ❌ | ❌ | `search-users` only |
| Businesses | ✅ | ✅ | — | |
| Locations | ✅ | — | — | Get, search, tags, fields, values, templates |
| Knowledge base | — | ✅ | — | FAQ entries |
| **Funnels / websites** | ❌ | ❌ | ❌ | Absent entirely |
| **Snapshots** | ❌ | ❌ | ❌ | Absent entirely |
| **AI employees / voice** | ❌ | ❌ | ❌ | Absent entirely |
| **Phone / A2P / LC config** | ❌ | ❌ | ❌ | Absent entirely |

---

## Domain detail

### Contacts — the workhorse
`search-contacts-advanced` (POST `/contacts/search`) is the primary read. `create-contact`, `update-contact`, `upsert-contact`, `add-tags`, `remove-tags`, `contacts.create-association` (bulk tag update), `create-note`, `update-note`, `create-task`, `get-all-notes`, `get-all-tasks`, `get-appointments-for-contact`, `add-remove-contact-from-business`, `add-contact-to-workflow`, `delete-contact-from-workflow`.

Prefer **upsert** over create when the contact might already exist — it's one call instead of search-then-branch, and it won't duplicate.

### Opportunities
`create-opportunity`, `Upsert-opportunity` (note the capital U — the operation IDs are not consistently cased), `update-opportunity` (name, value, assignment, **stage**, forecast, custom fields), `update-opportunity-status` (open/won/lost/abandoned + `lostReasonId`), `delete-opportunity`, `get-opportunity`, `search-opportunity`, `add-followers-opportunity`, `remove-followers-opportunity`.

**Stage moves go through `update-opportunity`; win/loss goes through `update-opportunity-status`.** They are different calls — using the wrong one silently does nothing useful.

`search-opportunity` filters on `pipelineId`, `pipelineStageId`, `status`, `assignedTo`, `contactId`, `date`/`startDate`/`endDate`, and can inline `getNotes`, `getTasks`, `getCalendarEvents`. That last part is a big efficiency win — one call instead of N.

### Conversations — including the scheduling superpower
`send-a-new-message` takes `type` (SMS | Email | WhatsApp | IG | FB | Custom | Live_Chat | InternalComment), `contactId`, and content (`message` for text, `html` + `subject` for email). Optional: `scheduledTimestamp` (**UTC seconds**), `attachments` (URLs), `templateId`, `fromNumber`/`toNumber`, `emailFrom`/`emailTo`/`emailCc`/`emailBcc`, `replyMessageId`, `threadId`.

`scheduledTimestamp` is the single most useful field in the whole catalog — it's how you build sequences without a workflow builder. `cancel-scheduled-message` / `cancel-scheduled-email-message` let you pull one back.

`InternalComment` posts a private team note into the conversation — perfect for leaving "Claude reviewed this, here's the context" without messaging the customer. Requires `mentions` (array of user IDs) and `@username<userId>id</userId>` syntax in the text.

Also: `get-messages`, `export-messages-by-location` (cursor-paginated, date-filterable — good for analysis), `get-message-transcription`, `get-message-recording`, `add-an-inbound-message` (log an inbound from an outside channel), `add-an-outbound-message` (log an external call).

### Custom values — the config store
`get-custom-values`, `create-custom-value`, `update-custom-value`. Referenced elsewhere in GHL as `{{custom_values.key}}`.

This is the highest-leverage building block in the account and almost nobody uses it well. Write offers, booking links, pricing, and copy fragments here; every workflow, template, and message that references them updates at once. When you build anything, **put the changeable parts in custom values** and tell the user that's the one place they edit later. It converts "ask Claude to change the copy" into "edit one field."

### Calendars
`get-slots` (free slots for a calendar in a date range, timezone-aware, filterable by user), `get-blocked-slots`, `create-appointment`, `edit-appointment`, `get-appointment`, `create-appointment-note`, `get-appointment-notes`, plus the full service-booking set (`create-service-booking`, `update-service-booking`, `get-service-bookings`, `delete-service-booking`).

`get-slots` + `create-appointment` means Claude can genuinely book people — check availability, propose real times in a message, then book. That's a complete loop.

### Email templates and campaigns
`create-email-template`, `update-email-template`, `import-email-template` (from a provider URL), `get-email-template`, `GET-all-or-email-sms-templates`. Campaigns: `create-email-campaign`, `update-email-campaign` (drafts only), `list-email-campaigns`, `get-email-campaign`, `get-campaign-stats` (works for campaigns, workflows, and bulk actions — the main analytics read), `list-workflow-campaigns`.

### Custom fields
Two overlapping paths: the `custom-fields` domain (`create-custom-field`, `update-custom-field`, `delete-custom-field`, `get-custom-fields-by-object-key`, folders) and the `locations` domain (`locations.create-custom-field`, `get-custom-fields?model=contact|opportunity`).

Use **`get-custom-fields` with `model=`** for discovery, because it returns `fieldKey` — which is what you need to filter searches by custom field value. Without the fieldKey your filters will silently match nothing.

---

## Gotchas that cause failures

1. **`search-contacts-advanced` uses `pageLimit`, not `limit`** (max 100). Passing `limit` fails or is ignored.
2. **Field names are camelCase. snake_case is explicitly rejected** in both `sort` and `filters`.
3. **`searchAfter` is a cursor you echo back from the previous page. Never fabricate one.**
4. **Look up `fieldKey` before filtering on a custom field.** Call `get-custom-fields?model=contact` first.
5. **`scheduledTimestamp` is seconds, not milliseconds.** A 1000× error puts your message in the year 55,000.
6. **Every write requires an `idempotencyKey`.** Make it meaningful and stable so retries are safe.
7. **Operation IDs are inconsistently cased** (`Upsert-opportunity`, `GET-all-or-email-sms-templates`). Copy them exactly from `search_operations` output; don't normalize them.
8. **`search_operations` is literal about vocabulary.** "workflows automation triggers" returns nothing; "workflow" returns six results. If a search comes back empty, retry with the single most obvious noun before concluding the capability is missing.
9. **Some read-shaped operations are typed `write`** because they POST (e.g. `fetchCalendarList`, `get-tags-by-ids`). Don't be alarmed; they still need an idempotency key.
10. **Multi-location connections require `locationId` on every call.** Single-location connections must omit it.

---

## Key request shapes

**Search contacts, newest first**
```json
{ "operationId": "search-contacts-advanced",
  "params": { "body": {
    "sort": [{ "field": "dateAdded", "direction": "desc" }],
    "pageLimit": 20
  }}}
```

**Filter by tag**
```json
{ "filters": [{ "field": "tags", "operator": "contains", "value": "roofing-hot" }],
  "pageLimit": 100 }
```
Operators available: `eq, not_eq, contains, not_contains, wildcard, not_wildcard, exists, not_exists, range, contains_set, gt, gte, lt, lte, nested`.

**Send an SMS now**
```json
{ "operationId": "send-a-new-message",
  "idempotencyKey": "followup-<contactId>-<yyyymmdd>",
  "reason": "Day-1 follow-up for inbound roofing lead",
  "params": { "body": {
    "type": "SMS", "contactId": "<id>",
    "message": "Hi Jane — saw your claim came through..."
  }}}
```

**Schedule the day-3 touch in the same pass**
```json
{ "params": { "body": {
  "type": "SMS", "contactId": "<id>",
  "message": "Following up on that roof inspection...",
  "scheduledTimestamp": 1755388800
}}}
```

**Move an opportunity to a new stage** → `update-opportunity` with `{ "pipelineStageId": "<id>" }`
**Mark it won** → `update-opportunity-status` with `{ "status": "won" }`

---

## Discovery recipe

At the start of a session where you'll build or write, run this orientation sweep. It's cheap and it makes every subsequent decision better:

1. `list_locations` — confirm which sub-account, and whether `locationId` is needed
2. `get-location` — business name, timezone (**needed for scheduling and send-hour etiquette**)
3. `get-pipelines` — pipeline and stage IDs; you cannot create these
4. `get-location-tags` — the existing tag vocabulary; match it rather than inventing a parallel one
5. `get-custom-fields?model=contact` — field keys for filtering
6. `get-custom-values` — what config already exists
7. `search-contacts-advanced` with `pageLimit: 1` — sanity-check that reads work and see total volume

Then tell the user what you found in one short paragraph before proposing anything. Reading their account before speaking is the difference between a consultant and a chatbot.
